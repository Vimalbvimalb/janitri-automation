package com.janitri.tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.janitri.pages.LoginPage;
import org.openqa.selenium.By;

public class LoginTests extends BaseTest {

    @Test
    public void testLoginButtonDisabledWhenFieldsAreEmpty() {
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertFalse(loginPage.isLoginButtonEnabled(), "Login button should be disabled when fields are empty.");
    }

    @Test
    public void testPasswordMaskingToggle() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterPassword("dummyPassword");
        Assert.assertEquals(loginPage.getPasswordFieldType(), "password", "Password should be masked by default.");
        loginPage.clickPasswordVisibilityToggle();
        Assert.assertEquals(loginPage.getPasswordFieldType(), "text", "Password should be unmasked after toggle.");
    }

    @Test
    public void testInvalidLoginShowsErrorMsg() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.enterUserId("invalidUser");
        loginPage.enterPassword("invalidPass");
        loginPage.clickLoginButton();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String expectedErrorMessage = "Invalid user id or password!";
        Assert.assertEquals(loginPage.getErrorMessageText(), expectedErrorMessage, "Error message for invalid credentials is not correct.");
    }

    @Test
    public void testPresenceOfPageElements() {
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertTrue(loginPage.getUserIdField().isDisplayed(), "User ID field is not displayed.");
        Assert.assertTrue(loginPage.getPasswordField().isDisplayed(), "Password field is not displayed.");
        Assert.assertTrue(driver.findElement(By.xpath("//h2[contains(text(),'Login')]")).isDisplayed(), "Login title is not displayed.");
    }
}
