package com.janitri.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver driver;
    private By userIdInput = By.xpath("//input[@name='userId']");
    private By passwordInput = By.xpath("//input[@name='password']");
    private By loginButton = By.xpath("//button[@type='submit']");
    private By passwordVisibilityToggle = By.xpath("//*[contains(@class, 'mat-icon-button')]");
    private By errorMessage = By.xpath("//p[contains(text(),'Invalid user id or password!')]");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterUserId(String userId) {
        driver.findElement(userIdInput).sendKeys(userId);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordInput).sendKeys(password);
    }

    public void clickLoginButton() {
        driver.findElement(loginButton).click();
    }

    public boolean isLoginButtonEnabled() {
        return driver.findElement(loginButton).isEnabled();
    }

    public void clickPasswordVisibilityToggle() {
        driver.findElement(passwordVisibilityToggle).click();
    }

    public String getPasswordFieldType() {
        return driver.findElement(passwordInput).getAttribute("type");
    }

    public String getErrorMessageText() {
        return driver.findElement(errorMessage).getText();
    }

    public WebElement getUserIdField() {
        return driver.findElement(userIdInput);
    }

    public WebElement getPasswordField() {
        return driver.findElement(passwordInput);
    }
}
